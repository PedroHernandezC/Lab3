# Dictionary Benchmark
## Student Information: 
**Name**:Pedro Hernandez Carranza 

**Student ID**: 008806974

**Repository Link**: https://github.com/PedroHernandezC/Lab3

## Reflection
For the most part all the iterative functions were fairly easy to implement. the hardest one was the palindrome2 functions. After some hints from th class TA my lab partner and I were able to some up with a one loop solution.

The recursive functions were all thought-provoking but after the first two they became much easier to write although explaining how the functions work are a little difficult. Tracing out some of the function calls on a white bord greatly helped in understanding the process.

- Collaboration & Sources:
  - I received help from my lab partner, Diego Delgado, and the TA, Regina Hartman. No online sources were used for this assignment.

- Implementation Details:
  - All functions were implemented as dictated by the initial comments and lab instructions. The functions have also been commented to aid in the thought process of the function.

- Testing & Status:
  - Testing was done by using provided testing functions in the main.cpp file. In the development process temporary cout statements were used, but they have since been removed.
  - All functions pass the given testing functions